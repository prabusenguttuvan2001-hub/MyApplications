﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOTNET_Assessment1.Models
{
    public class Tier
    {
        public string TierName {  get; set; }
        public bool IsHighRisk { get; set; }
    }
}
