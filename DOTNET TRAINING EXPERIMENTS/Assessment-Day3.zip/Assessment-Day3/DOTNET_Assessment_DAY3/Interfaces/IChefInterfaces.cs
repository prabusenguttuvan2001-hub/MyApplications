﻿namespace DOTNET_Assessment_DAY3.Interfaces
{
    public interface IChefInterfaces
    {
        public void CallTable1();
        public void CallTable2();
    }
}
