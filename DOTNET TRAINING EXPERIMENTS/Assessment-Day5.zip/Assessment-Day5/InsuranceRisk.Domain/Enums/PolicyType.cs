﻿
namespace InsuranceRisk.Domain.Enums
{
    public enum PolicyType
    {
        Car,
        Bike,
        Health

    }
}
