﻿
namespace InsuranceRisk.Domain.Enums
{
    public enum RiskTier
    {
        Low,
        Medium,
        High
    }
}
