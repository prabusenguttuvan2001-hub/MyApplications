﻿using DOTNET_LEARNING_ASSESSMENT.EnumLearning;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;

namespace DOTNET_LEARNING_ASSESSMENT.LearningTasks
{
    internal class InitTaskLearning
    {
         public string Name { get; init; } 
         public int age { get; init; }
       
        //static void Main(string[] args)
        //{
        //    InitTaskLearning m = new InitTaskLearning { Name= "Prabu" };

         
        //    Console.WriteLine("name: "+m.Name); // it prints Prabu
        //    Console.WriteLine("age :"+ m.age);
       
        //    //m.Name = "Naruto"; // we can't able to re-assign the value which is set to be init

        //}
    }


}
